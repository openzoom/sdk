--------------------------------------------------------------------------------

  OpenZoom Caral

--------------------------------------------------------------------------------


  Installation
  ------------

  python setup.py install

  
  Dependencies
  ------------
  
  * Python Imaging Library (PIL)
    <http://www.pythonware.com/products/pil/>
  
  * Python Deep Zoom Tools
    <http://open-zoom.googlecode.com/>
  
  

--------------------------------------------------------------------------------

  Developed by
  
  Daniel Gasienica
  <daniel@gasienica.ch>
  <http://gasi.ch/>
  
  ----------------------------------------------------------------------------

  Powered by OpenZoom <http://openzoom.org/>

--------------------------------------------------------------------------------

  OpenZoom Caral License: GNU General Public License v3
  <http://www.gnu.org/licenses/gpl-3.0.txt>
  
--------------------------------------------------------------------------------

  Changelog
  ---------
  
  0.2 (2009-04-06)
  ----------------
  * Fixed a bug where OpenZoom descriptors
    were written with wrong tile extensions.
  
  0.1 (2009-03-30)
  ----------------
  �First release. Nothing is new, or everything is new,
   depending on how you think about it.� -- Google