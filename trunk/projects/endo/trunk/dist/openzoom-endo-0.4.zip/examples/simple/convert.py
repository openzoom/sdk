import openzoom

creator = openzoom.ImageCreator()
creator.create("me.jpg", "me", [0, 500])
