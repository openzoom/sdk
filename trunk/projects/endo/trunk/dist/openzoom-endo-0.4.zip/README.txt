--------------------------------------------------------------------------------

  OpenZoom Endo

--------------------------------------------------------------------------------


  Installation
  ------------

  *  Unzip and install Python Deep Zoom Tools library from lib directory.
  *  Unzip and install OpenZoom Caral Python library from lib directory.


  Instructions
  ------------
  
  * Check out simple example in example directory
    or follow short online tutorial on
    <http://gasi.ch/blog/inline-multiscale-image-replacement/>

  
  Dependencies
  ------------
  
  * OpenZoom Caral
    <http://open-zoom.googlecode.com/>
  
  * Python Deep Zoom Tools
    <http://open-zoom.googlecode.com/>
  
  

--------------------------------------------------------------------------------

  Developed by
  
  Daniel Gasienica
  <daniel@gasienica.ch>
  <http://gasi.ch/>
  
  ----------------------------------------------------------------------------

  Powered by OpenZoom <http://openzoom.org/>

--------------------------------------------------------------------------------

  OpenZoom Endo License: GNU General Public License v3
  <http://www.gnu.org/licenses/gpl-3.0.txt>
  
--------------------------------------------------------------------------------

  Changelog
  ---------
  
  0.4 (2009-04-08)
  ----------------
  �First release. Nothing is new, or everything is new,
   depending on how you think about it.� -- Google