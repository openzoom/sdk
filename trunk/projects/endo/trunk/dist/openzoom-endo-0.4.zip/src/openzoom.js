/*
 * OpenZoom Endo 0.4
 * http://openzoom.org/
 *
 * Copyright (c) 2007-2009, Daniel Gasienica <daniel@gasienica.ch>
 * License: GNU General Public License v3
 * <http://www.gnu.org/licenses/gpl.html>
 */
jQuery.noConflict();
jQuery(document).ready(function() {
    jQuery.openzoom.run();
})
